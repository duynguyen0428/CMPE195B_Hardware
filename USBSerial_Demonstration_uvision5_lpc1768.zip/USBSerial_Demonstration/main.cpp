#include "mbed.h"
#include <string>
#include "USBSerial.h"
#define MAX_BUFFER_LENGTH 1024
#define BAUDRATE 9600
//Virtual serial port over USB
Serial pc(USBTX, USBRX);
DigitalOut myled(LED1);
USBSerial serial(0x04B8,0x0E03);
//USBSerial serial;
Timer timer;
uint8_t buf[4096];
void serialtransmit(){
    pc.putc(serial.getc());
}
    int index_ = 0;
void serial_read(){
   timer.start();
   while(timer.read() < 2){
//    pc.printf("%f",timer.read());   
        buf[index_] = pc.getc(); 
        index_++;
    }
    timer.stop();
    timer.reset();
//    index_=0;
   //while(serial.available()>0){
//       pc.putc(serial.getc());
//       //char inchar = serial.getc();
////        if(inchar != '\n'){
////        buf[index_] = serial.getc(); 
////        index_++;
////            }
//}
//       // pc.printf("%s", buf);  
//      // int index; 
////        for(index = 0; index < sizeof(buf); index++)
////        {
////              buf[index] = serial.getc(); 
////        }  
//    }
//    index_=0;
//    pc.printf("serial data : "+ serial.available());
//    timer.stop();
//pc.putc(serial.getc());
}

int counter=0;
void send_data(){//
//    timer.start();
//    pc.printf("%s\n", buf);  
   // while(timer.read() < 1){
//          pc.printf("inside send");
//         
//    }
//    timer.stop();
//    memset(buf,0,sizeof(buf));
//    pc.printf("%s\n",buf);

 //   int index_1; 
//    for(index_1 = 0; index_1 < index_; index_1++)
//    {
//         pc.putc(buf[index_1]);
//  //      if(buf[index] != 0){
////          
////            }    
//    }
////    pc.putc(counter);
    serial.printf("%s",buf);
    serial.printf("\n");
    index_=0;
    memset(buf,' ',sizeof(buf));
}
int main(void) {
    char buffer[MAX_BUFFER_LENGTH];
    pc.baud(BAUDRATE);
     // Increase the TX buffer from the default 256bytes to 1024bytes.
//     if (pc.txBufferSetSize(1024) != MODSERIAL::Ok) {
//        error("Failed to allocate memory for new buffer");
//     }
//     serial.txtBufferSetSize(1024);
    //serial.printf("I am a virtual serial port \n"); 
    pc.printf("I am a virtual serial port\r\n");
    int counter = 0;
        while(1)
        {    
            
          if(serial.available() > 0){
                char temp_buffer[serial.available()];
                int i;
                for(i = 0; i < sizeof(temp_buffer); i++){
                        temp_buffer[i] = serial.getc();
                    }
                pc.printf("%s",temp_buffer);
            }
            wait_us(500);
        //if(serial.available() > 0){
    //       pc.putc(serial.getc());
    //       wait(0.01f);
    //        pc.printf("reach send");
    //       send_data();
    //pc.printf("Aval bytes on buffer %i \n" , serial.available());
//    pc.putc(serial.getc());
//    wait_us(10);
/*    char recv = serial.getc(); 
        //if(serial.available() > 0){
            //pc.printf("reach here");
//             recv = serial.getc();          
//        }
         if(recv != '\n' && counter < 200)
            {
                buffer[counter] = recv; 
                counter++;  
            }
            else
            {                
                
//               pc.printf("%s",buffer);
                int index_,i = 0;
                for(;i < sizeof(buffer);i++)
                {
                    if(buffer[i] != ' ')
                    {
                        index_++;
                    }
                 }
        pc.printf(" received %i \n",index_);  
            index_, i,counter = 0;
            memset(buffer,' ',sizeof(buffer));    
//            }       */
//    }    
       //pc.putc(serial.getc());
       //pc.attach(&serialtransmit);
       //int i;
//       if(serial.available() > 0){
//            for(i=0; i < serial.available();i++){
//                buffer[i] = serial.getc();  
//            }          
//        }
           // string raw_text = string(buffer);
//            pc.puts(buffer);
//            pc.printf("\n");
        //serial.printf("I am a virtual serial port\r\n");
    //    serial.scanf("%s", buf);
//        serial.printf("recv: %s", buf);
//        pc.printf("recv: %s\r\n", buf);        
    }
}